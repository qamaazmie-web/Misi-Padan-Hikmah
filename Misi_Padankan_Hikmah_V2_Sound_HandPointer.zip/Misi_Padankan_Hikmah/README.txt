MISI PADANKAN HIKMAH — EKSPEDISI RIMBA AJAIB

KANDUNGAN
- index.html: permainan interaktif 5 soalan
- assets/: gambar haiwan dan latar hutan

CARA MAIN
1. Buka index.html dalam Chrome atau Edge.
2. Tekan “Mulakan Pengembaraan” atau “Mula Misi”.
3. Pilih satu kad Peribahasa dan satu kad Pengajaran yang sepadan dengan situasi.
4. Seret kad dengan tetikus, atau aktifkan kamera untuk cuba kawalan cubit ibu jari + telunjuk.
5. Tekan “Semak Padanan”. Jawapan betul memberikan 20 mata dan 1 Kristal Hikmah.
6. Lengkapkan 5 misi.

AUDIO
Muzik latar dan kesan bunyi dijana terus oleh Web Audio API. Tiada fail audio luaran diperlukan. Bunyi bermula selepas pengguna menekan butang kerana sekatan autoplay pelayar.

KAMERA
Kawalan tangan menggunakan MediaPipe Hands yang dimuatkan melalui CDN, jadi sambungan internet diperlukan. Kamera memerlukan kebenaran pengguna dan biasanya berfungsi apabila laman diterbitkan melalui HTTPS. Jika kamera tidak berfungsi, permainan masih boleh dimainkan menggunakan tetikus.

PENERBITAN
Untuk GitHub Pages, muat naik index.html dan keseluruhan folder assets/ ke root repository. Kekalkan struktur folder seperti dalam ZIP ini.
